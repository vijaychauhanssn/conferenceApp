(function() {
	'use strict';

	angular
		.module('conference.common', ['ionic']);
})();
