"use strict";

angular.module('config', [])

    .constant('ENV', {
        name: 'development',
        dataProvider: 'FIREBASE',
        firebaseConfig: {
            apiKey: 'AIzaSyAhs7iwEzgsymXWqR8j61V0dA2uAbGmkxU',
            authDomain: 'conference-ionic-c665d.firebaseapp.com',
            databaseURL: 'https://conference-ionic-c665d.firebaseio.com',
            storageBucket: 'conference-ionic-c665d.appspot.com',
            messagingSenderId: '669701331606'
        }
    })

;